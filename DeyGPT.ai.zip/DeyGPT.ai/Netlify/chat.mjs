
export default async (request) => {
  if (request.method !== "POST") {
    return Response.json(
      { error: "Método não permitido." },
      { status: 405 }
    );
  }

  try {
    const { message } = await request.json();

    if (!message || typeof message !== "string") {
      return Response.json(
        { error: "Mensagem inválida." },
        { status: 400 }
      );
    }

    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
      throw new Error("OPENAI_API_KEY não configurada.");
    }

    const response = await fetch(
      "https://api.openai.com/v1/responses",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "gpt-6-luna",
          instructions: "Você é um assistente de IA útil, claro e amigável. Responda em português quando o usuário falar português.",
          input: message,
          max_output_tokens: 1000
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      return Response.json(
        { error: data.error?.message || "Erro na API OpenAI." },
        { status: response.status }
      );
    }

    const reply = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n");

    return Response.json({ reply });

  } catch (error) {
    return Response.json(
      { error: error.message || "Erro interno." },
      { status: 500 }
    );
  }
};
